import pandas as pd
import streamlit as st
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from tkinter import *
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier
df1 = pd.read_csv(r"C:\Users\user\Desktop\Diet\Diet\food.csv")
le = LabelEncoder()
for col in df1:
  if type(col) == "object":
    col = le.fit_transform(col)
breakfast = []
lunch = []
dinner = []

for food in range(len(df1['Food_items'])):
  if df1['Breakfast'][food] == 1:
    breakfast.append(df1['Food_items'][food])
  if df1['Lunch'][food] == 1:
    lunch.append(df1['Food_items'][food])
  if df1['Dinner'][food] == 1:
    dinner.append(df1['Food_items'][food])
  
print(breakfast)
print(lunch)
print(dinner)

bf = len(breakfast)
lunch = len(lunch)
dinner = len(dinner)

lst = [bf,lunch,dinner]
df = pd.DataFrame(lst, columns = ['count'])
df.index = ['Breakfast', 'Lunch', 'Dinner']
data=pd.read_csv(r'C:\Users\user\Desktop\Diet\Diet\food.csv')
Breakfastdata=data['Breakfast']
BreakfastdataNumpy=Breakfastdata.to_numpy()
    
Lunchdata=data['Lunch']
LunchdataNumpy=Lunchdata.to_numpy()
    
Dinnerdata=data['Dinner']
DinnerdataNumpy=Dinnerdata.to_numpy()
Food_itemsdata=data['Food_items']
import streamlit as st
st.title("DIET FOOD SUGGESTER")
def entry_fields():
  name = st.selectbox("Enter your Gender:",("Male","Female"))
  age = st.number_input("Enter your Age", value=1, step=1)
  vnv_options = ["Veg", "NonVeg"]
  vnv = st.selectbox("Are you Veg or NonVeg", vnv_options, index=1) 
  vnv = 1 if vnv == "NonVeg" else 0
  weight = st.number_input("Enter your weight", value=60.0, step=0.1)
  height = st.number_input("Enter your height", value=140.0, step=0.1)
  return age,vnv,weight,height

age, veg, weight, height = entry_fields()
    
breakfastfoodseparated=[]
Lunchfoodseparated=[]
Dinnerfoodseparated=[]
        
breakfastfoodseparatedID=[]
LunchfoodseparatedID=[]
DinnerfoodseparatedID=[]
        
for i in range(len(Breakfastdata)):
  if BreakfastdataNumpy[i]==1:
    breakfastfoodseparated.append( Food_itemsdata[i] )
    breakfastfoodseparatedID.append(i)
  if LunchdataNumpy[i]==1:
    Lunchfoodseparated.append(Food_itemsdata[i])
    LunchfoodseparatedID.append(i)
  if DinnerdataNumpy[i]==1:
    Dinnerfoodseparated.append(Food_itemsdata[i])
    DinnerfoodseparatedID.append(i)
        
# retrieving Lunch data rows by loc method |
LunchfoodseparatedIDdata = data.iloc[LunchfoodseparatedID]
LunchfoodseparatedIDdata=LunchfoodseparatedIDdata.T
#print(LunchfoodseparatedIDdata)
val=list(np.arange(5,15))
Valapnd=[0]+val
LunchfoodseparatedIDdata=LunchfoodseparatedIDdata.iloc[Valapnd]
LunchfoodseparatedIDdata=LunchfoodseparatedIDdata.T
#print(LunchfoodseparatedIDdata)

# retrieving Breafast data rows by loc method 
breakfastfoodseparatedIDdata = data.iloc[breakfastfoodseparatedID]
breakfastfoodseparatedIDdata=breakfastfoodseparatedIDdata.T
val=list(np.arange(5,15))
Valapnd=[0]+val
breakfastfoodseparatedIDdata=breakfastfoodseparatedIDdata.iloc[Valapnd]
breakfastfoodseparatedIDdata=breakfastfoodseparatedIDdata.T
        
        
# retrieving Dinner Data rows by loc method 
DinnerfoodseparatedIDdata = data.iloc[DinnerfoodseparatedID]
DinnerfoodseparatedIDdata=DinnerfoodseparatedIDdata.T
val=list(np.arange(5,15))
Valapnd=[0]+val
DinnerfoodseparatedIDdata=DinnerfoodseparatedIDdata.iloc[Valapnd]
DinnerfoodseparatedIDdata=DinnerfoodseparatedIDdata.T
        
#calculating BMI
bmi = weight/((height/100)**2) 
agewiseinp=0
        
for lp in range (0,80,20):
  test_list=np.arange(lp,lp+20)
  for i in test_list: 
    if(i == age):
      tr=round(lp/20)  
      agecl=round(lp/20)    

        
#conditions
st.write("Your body mass index is: ", bmi)
if ( bmi < 16):
  st.markdown("## Acoording to your BMI, you are Severely Underweight")
  clbmi=4
elif ( bmi >= 16 and bmi < 18.5):
  st.markdown("## Acoording to your BMI, you are Underweight")
  clbmi=3
elif ( bmi >= 18.5 and bmi < 25):
  st.markdown("## Acoording to your BMI, you are Healthy")
  clbmi=2
elif ( bmi >= 25 and bmi < 30):
  st.markdown("## Acoording to your BMI, you are Overweight")
  clbmi=1
elif ( bmi >=30):
  st.markdown("## Acoording to your BMI, you are Severely Overweight")
  clbmi=0

    #converting into numpy array
DinnerfoodseparatedIDdata=DinnerfoodseparatedIDdata.to_numpy()
LunchfoodseparatedIDdata=LunchfoodseparatedIDdata.to_numpy()
breakfastfoodseparatedIDdata=breakfastfoodseparatedIDdata.to_numpy()
ti=(clbmi+agecl)/2
    
## K-Means Based  Dinner Food
Datacalorie=DinnerfoodseparatedIDdata[1:,1:len(DinnerfoodseparatedIDdata)]

X = np.array(Datacalorie)
kmeans = KMeans(n_clusters=3, random_state=0).fit(X)

XValu=np.arange(0,len(kmeans.labels_))
    
# retrieving the labels for dinner food
dnrlbl=kmeans.labels_
## K-Means Based  lunch Food
Datacalorie=LunchfoodseparatedIDdata[1:,1:len(LunchfoodseparatedIDdata)]
    
X = np.array(Datacalorie)
kmeans = KMeans(n_clusters=3, random_state=0).fit(X)
    
XValu=np.arange(0,len(kmeans.labels_))
    
# retrieving the labels for lunch food
lnchlbl=kmeans.labels_
    
## K-Means Based  lunch Food
Datacalorie=breakfastfoodseparatedIDdata[1:,1:len(breakfastfoodseparatedIDdata)]
    
X = np.array(Datacalorie)
kmeans = KMeans(n_clusters=3, random_state=0).fit(X)
    
XValu=np.arange(0,len(kmeans.labels_))
    
# retrieving the labels for breakfast food
brklbl=kmeans.labels_
    
inp=[]
## Reading of the Dataet
datafin=pd.read_csv(r'C:\Users\user\Desktop\Diet\Diet\nutrition_distriution.csv')

## train set
dataTog=datafin.T
bmicls=[0,1,2,3,4]
agecls=[0,1,2,3,4]
weightlosscat = dataTog.iloc[[1,2,7,8]]
weightlosscat=weightlosscat.T
weightgaincat= dataTog.iloc[[0,1,2,3,4,7,9,10]]
weightgaincat=weightgaincat.T
healthycat = dataTog.iloc[[1,2,3,4,6,7,9]]
healthycat=healthycat.T
weightlosscatDdata=weightlosscat.to_numpy()
weightgaincatDdata=weightgaincat.to_numpy()
healthycatDdata=healthycat.to_numpy()
weightlosscat=weightlosscatDdata[1:,0:len(weightlosscatDdata)]
weightgaincat=weightgaincatDdata[1:,0:len(weightgaincatDdata)]
healthycat=healthycatDdata[1:,0:len(healthycatDdata)]
    
    
weightlossfin=np.zeros((len(weightlosscat)*5,6),dtype=np.float32)
weightgainfin=np.zeros((len(weightgaincat)*5,10),dtype=np.float32)
healthycatfin=np.zeros((len(healthycat)*5,9),dtype=np.float32)
t=0
r=0
s=0
yt=[]
yr=[]
ys=[]
for zz in range(5):
  for jj in range(len(weightlosscat)):
    valloc=list(weightlosscat[jj])
    valloc.append(bmicls[zz])
    valloc.append(agecls[zz])
    weightlossfin[t]=np.array(valloc)
    yt.append(brklbl[jj])
    t+=1
  for jj in range(len(weightgaincat)):
    valloc=list(weightgaincat[jj])
    valloc.append(bmicls[zz])
    valloc.append(agecls[zz])
    weightgainfin[r]=np.array(valloc)
    yr.append(lnchlbl[jj])
    r+=1
  for jj in range(len(healthycat)):
    valloc=list(healthycat[jj])
    valloc.append(bmicls[zz])
    valloc.append(agecls[zz])
    healthycatfin[s]=np.array(valloc)
    ys.append(dnrlbl[jj])
    s+=1

    
X_test=np.zeros((len(weightlosscat),6),dtype=np.float32)


    
#randomforest
for jj in range(len(weightlosscat)):
  valloc=list(weightlosscat[jj])
  valloc.append(agecl)
  valloc.append(clbmi)
  X_test[jj]=np.array(valloc)*ti
    
    
    
X_train=weightlossfin# Features
y_train=yt # Labels

#Create a Gaussian Classifier
clf=RandomForestClassifier(n_estimators=100)
    
#Train the model using the training sets y_pred=clf.predict(X_test)
clf.fit(X_train,y_train)
    
#st.write (X_test[1])
X_test2 = X_test
y_pred = clf.predict(X_test2)
BZ=[]
filename = r"Diet\food_items.csv"
column_to_extract = "items"
value_to_check = 1
import csv

BZ_breakfast = ['Oatmeal']
BZ_lunch = []
BZ_dinner = []


MEDICAL_CON=str(st.selectbox("CHOOSE YOUR MEDICAL CONDITION",['Diabetes','heart_disease','anemia','Blood_pressure','healthy']))
if st.button('Click me'):    
    st.markdown('SUGGESTED FOOD ITEMS according to your BMI ::')

    for ii in range(len(y_pred)):
        if y_pred[ii] == 2:
            BZ_lunch.append(Food_itemsdata[ii])
            findata=Food_itemsdata[ii]
            BZ.append(findata)
        elif y_pred[ii] == 1:
            BZ_dinner.append(Food_itemsdata[ii])
            findata=Food_itemsdata[ii]
            BZ.append(findata)
        elif y_pred[ii] == 3:
            BZ_breakfast.append(Food_itemsdata[ii])
            findata=Food_itemsdata[ii]
            BZ.append(findata)  
    
    df_breakfast = pd.DataFrame({'Breakfast': BZ_breakfast})
    df_lunch = pd.DataFrame({'Lunch': BZ_lunch})
    df_dinner = pd.DataFrame({'Dinner': BZ_dinner})

    col1, col2, col3 = st.columns(3)

    with col1:
        st.write(df_breakfast)

    with col2:
        st.write(df_lunch)

    with col3:
        st.write(df_dinner)


    if MEDICAL_CON !='healthy':
        st.markdown(f'##### As you have this medical condition you must AVOID eating these food items :')
        column_to_check = MEDICAL_CON
        items_list = []

        with open(filename, "r") as csvfile:
            csv_reader = csv.DictReader(csvfile)
            for row in csv_reader:
                if row[column_to_check] == str(value_to_check):
                    items_list.append(row[column_to_extract])
        st.write(items_list)
        st.write ('##### SUGGESTED food items according to your MEDICAL CONDITION ::')

        result = [item for item in BZ if item not in items_list]
        st.write(result)
    else:
       st.markdown('## EAT HEALTHY, BE HEALTHY')


