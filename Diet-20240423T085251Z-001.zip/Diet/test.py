import pandas as pd

# Read the CSV file into a pandas dataframe
df = pd.read_csv('food_items.csv')

# Define a list of keywords related to diabetes
diabetes_keywords = ['sugar', 'honey', 'doughnuts', 'caramel', 'popcorn', 'rice', 'pasta', 'macaroni', 'french fries', 'cheese pizza', 'burger', 'bacon', 'beef sticks']

# Create a new column "Diabetes" with a default value of 0
df['Diabetes'] = 0

# Iterate over each row in the dataframe and check if any of the keywords are present in the "Food Item" column
for index, row in df.iterrows():
    food_item = row['items'].lower()  # convert the food item to lowercase for case-insensitive matching
    for keyword in diabetes_keywords:
        if keyword in food_item:
            df.at[index, 'Diabetes'] = 1
            break  # if a keyword is found, break out of the loop to avoid setting the value to 0 again

# Write the modified dataframe back to a new CSV file
df.to_csv('food_items.csv', index=False)
