import csv

column_list = []  # initialize an empty list to store the column data

with open('food.csv', newline='') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        column_list.append(row['Food_items'])  # replace 'column_name' with the actual name of the column you want to extract

print(column_list)

with open('food health.csv', newline='') as csvfile:
    reader = csv.reader(csvfile)
    data = [row for row in reader]

# Add new values to the desired column using a list
new_column = ['Asparagus Cooked', 'Avocados', 'Bananas', 'Bagels made in wheat', 'Berries', 'Brocolli', 'Brown Rice', 'Cauliflower', 'American cheese', 'Coffee', 'Corn', 'Dark chocolates', 'Grapes', 'Milk', 'Cashew Nuts', 'Onions', 'Orange', 'Pasta canned with tomato sauce', 'Pears', 'Peas', 'Protein Powder', 'Pumpkin', 'Tuna Salad', 'Tuna Fish', 'Peproni Pizza', 'Cheese Pizza', 'French Fries', 'Chicken Burger', 'Cheese Burger', 'Chicken Sandwich', 'Sugar Doughnuts', 'Chocolate Doughnuts', 'Pop Corn - Caramel', 'Pop Corn', 'Dosa', 'Idli', 'Poha', 'Chappati', 'Tomato', 'Yogurt', 'Brownie', 'Noodles', 'Uttapam', 'Bhaji Pav', 'Dal Makhani', 'Almonds', 'Mushrooms', 'Egg Yolk cooked', 'Sweet Potatoes cooked', 'Boiled Potatoes', 'White Rice', 'Orange juice', 'Greek yogurt plain', 'Oat Bran Cooked', 'Green Tea', 'Chia seeds', 'Cottage cheese with vegetables', 'Salmon', 'Cereals-Corn Flakes', 'Beans', 'Lentils', 'Pasta with corn homemade', 'Tea', 'Apples', 'Strawberries', 'Quninoa', 'Goat meat', 'Rabbit meat', 'Chicken Strips', 'Steak Fries', 'Mexican Rice', 'Fried Shrimp', 'Spaghetti and meatballs', 'Macroni n Cheese ', 'Pork cooked', 'Bacon cooked', 'Nachos', 'Chicken Popcorn', 'Turkey cooked', 'Oyster cooked', 'Beef sticks', 'Banana Chips', 'Honey', 'Chocolate Icecream', 'Vanilla Ice cream', 'Strawberry Icecream', 'Marshmallows', 'Chocolate milk', 'Rice Pudding']
for i, row in enumerate(data):
    row.append(new_column[i])

# Write the modified data back to the CSV file
with open('food health.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows(data)
import csv

food_items = ['Asparagus Cooked', 'Avocados', 'Bananas', 'Bagels made in wheat', 'Berries', 'Brocolli', 'Brown Rice', 'Cauliflower', 'American cheese', 'Coffee', 'Corn', 'Dark chocolates', 'Grapes', 'Milk', 'Cashew Nuts', 'Onions', 'Orange', 'Pasta canned with tomato sauce', 'Pears', 'Peas', 'Protein Powder', 'Pumpkin', 'Tuna Salad', 'Tuna Fish', 'Peproni Pizza', 'Cheese Pizza', 'French Fries', 'Chicken Burger', 'Cheese Burger', 'Chicken Sandwich', 'Sugar Doughnuts', 'Chocolate Doughnuts', 'Pop Corn - Caramel', 'Pop Corn', 'Dosa', 'Idli', 'Poha', 'Chappati', 'Tomato', 'Yogurt', 'Brownie', 'Noodles', 'Uttapam', 'Bhaji Pav', 'Dal Makhani', 'Almonds', 'Mushrooms', 'Egg Yolk cooked', 'Sweet Potatoes cooked', 'Boiled Potatoes', 'White Rice', 'Orange juice', 'Greek yogurt plain', 'Oat Bran Cooked', 'Green Tea', 'Chia seeds', 'Cottage cheese with vegetables', 'Salmon', 'Cereals-Corn Flakes', 'Beans', 'Lentils', 'Pasta with corn homemade', 'Tea', 'Apples', 'Strawberries', 'Quninoa', 'Goat meat', 'Rabbit meat', 'Chicken Strips', 'Steak Fries', 'Mexican Rice', 'Fried Shrimp', 'Spaghetti and meatballs', 'Macroni n Cheese ', 'Pork cooked', 'Bacon cooked', 'Nachos', 'Chicken Popcorn', 'Turkey cooked', 'Oyster cooked', 'Beef sticks', 'Banana Chips', 'Honey', 'Chocolate Icecream', 'Vanilla Ice cream', 'Strawberry Icecream', 'Marshmallows', 'Chocolate milk', 'Rice Pudding']

with open('health.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    for item in food_items:
        writer.writerow([item])
import csv

food_items = ['Asparagus Cooked', 'Avocados', 'Bananas', 'Bagels made in wheat', 'Berries', 'Brocolli', 'Brown Rice', 'Cauliflower', 'American cheese', 'Coffee', 'Corn', 'Dark chocolates', 'Grapes', 'Milk', 'Cashew Nuts', 'Onions', 'Orange', 'Pasta canned with tomato sauce', 'Pears', 'Peas', 'Protein Powder', 'Pumpkin', 'Tuna Salad', 'Tuna Fish', 'Peproni Pizza', 'Cheese Pizza', 'French Fries', 'Chicken Burger', 'Cheese Burger', 'Chicken Sandwich', 'Sugar Doughnuts', 'Chocolate Doughnuts', 'Pop Corn - Caramel', 'Pop Corn', 'Dosa', 'Idli', 'Poha', 'Chappati', 'Tomato', 'Yogurt', 'Brownie', 'Noodles', 'Uttapam', 'Bhaji Pav', 'Dal Makhani', 'Almonds', 'Mushrooms', 'Egg Yolk cooked', 'Sweet Potatoes cooked', 'Boiled Potatoes', 'White Rice', 'Orange juice', 'Greek yogurt plain', 'Oat Bran Cooked', 'Green Tea', 'Chia seeds', 'Cottage cheese with vegetables', 'Salmon', 'Cereals-Corn Flakes', 'Beans', 'Lentils', 'Pasta with corn homemade', 'Tea', 'Apples', 'Strawberries', 'Quninoa', 'Goat meat', 'Rabbit meat', 'Chicken Strips', 'Steak Fries', 'Mexican Rice', 'Fried Shrimp', 'Spaghetti and meatballs', 'Macroni n Cheese ', 'Pork cooked', 'Bacon cooked', 'Nachos', 'Chicken Popcorn', 'Turkey cooked', 'Oyster cooked', 'Beef sticks', 'Banana Chips', 'Honey', 'Chocolate Icecream', 'Vanilla Ice cream', 'Strawberry Icecream', 'Marshmallows', 'Chocolate milk', 'Rice Pudding']

with open('food_items.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['items'])  # Add heading to the first row
    for item in food_items:
        writer.writerow([item])
        
import pandas as pd

# Read the CSV file into a pandas dataframe
df = pd.read_csv('your_file.csv')

# Define a list of keywords related to diabetes
diabetes_keywords = ['sugar', 'honey', 'doughnuts', 'caramel', 'popcorn', 'rice', 'pasta', 'macaroni', 'french fries', 'cheese pizza', 'burger', 'bacon', 'beef sticks']

# Create a new column "Diabetes" with a default value of 0
df['Diabetes'] = 0

# Iterate over each row in the dataframe and check if any of the keywords are present in the "Food Item" column
for index, row in df.iterrows():
    food_item = row['Food Item'].lower()  # convert the food item to lowercase for case-insensitive matching
    for keyword in diabetes_keywords:
        if keyword in food_item:
            df.at[index, 'Diabetes'] = 1
            break  # if a keyword is found, break out of the loop to avoid setting the value to 0 again

# Write the modified dataframe back to a new CSV file
df.to_csv('new_file.csv', index=False)
import pandas as pd

# Read the CSV file into a pandas dataframe
df = pd.read_csv('food_items.csv')

# Define a list of keywords related to diabetes
heart_disease = ['American cheese', 'Sugar Doughnuts', 'Chocolate Doughnuts', 'Pop Corn - Caramel','French Fries', 'Chicken Burger', 'Cheese Burger', 'Fried Shrimp', 'Spaghetti and meatballs','Macroni n Cheese', 'Bacon cooked', 'Beef sticks', 'Honey', 'Chocolate Icecream','Vanilla Ice cream', 'Strawberry Icecream', 'Marshmallows', 'Chocolate milk', 'Rice Pudding']


# Create a new column "Diabetes" with a default value of 0
df['heart_disease'] = 0

# Iterate over each row in the dataframe and check if any of the keywords are present in the "Food Item" column
for index, row in df.iterrows():
    food_item = row['items'].lower()  # convert the food item to lowercase for case-insensitive matching
    for keyword in heart_disease:
        if keyword in food_item:
            df.at[index, 'heart_disease'] = 1
            break  # if a keyword is found, break out of the loop to avoid setting the value to 0 again

# Write the modified dataframe back to a new CSV file
df.to_csv('food_items.csv', index=False)
import pandas as pd

# Read the CSV file into a pandas dataframe
df = pd.read_csv('food_items.csv')

# Define a list of keywords related to diabetes
Blood_pressure = ['American cheese', 'Sugar Doughnuts', 'Chocolate Doughnuts', 'Pop Corn - Caramel','French Fries', 'Chicken Burger', 'Cheese Burger', 'Fried Shrimp', 'Spaghetti and meatballs','Macroni n Cheese', 'Bacon cooked', 'Beef sticks', 'Honey', 'Chocolate Icecream','Vanilla Ice cream', 'Strawberry Icecream', 'Marshmallows', 'Chocolate milk', 'Rice Pudding']


# Create a new column "Diabetes" with a default value of 0
df['Blood_pressure'] = 0

# Iterate over each row in the dataframe and check if any of the keywords are present in the "Food Item" column
for index, row in df.iterrows():
    food_item = row['items'].lower()  # convert the food item to lowercase for case-insensitive matching
    for keyword in Blood_pressure:
        if keyword in food_item:
            df.at[index, 'Blood_pressure'] = 1
            break  # if a keyword is found, break out of the loop to avoid setting the value to 0 again

# Write the modified dataframe back to a new CSV file
df.to_csv('food_items.csv', index=False)
import pandas as pd

# Read the CSV file into a pandas dataframe
df = pd.read_csv('food_items.csv')

# Define a list of keywords related to diabetes
anemia = ['American cheese', 'Sugar Doughnuts', 'Chocolate Doughnuts', 'Pop Corn - Caramel','French Fries', 'Chicken Burger', 'Cheese Burger', 'Fried Shrimp', 'Spaghetti and meatballs','Macroni n Cheese', 'Bacon cooked', 'Beef sticks', 'Honey', 'Chocolate Icecream','Vanilla Ice cream', 'Strawberry Icecream', 'Marshmallows', 'Chocolate milk', 'Rice Pudding']


# Create a new column "Diabetes" with a default value of 0
df['anemia'] = 0

# Iterate over each row in the dataframe and check if any of the keywords are present in the "Food Item" column
for index, row in df.iterrows():
    food_item = row['items'].lower()  # convert the food item to lowercase for case-insensitive matching
    for keyword in anemia:
        if keyword in food_item:
            df.at[index, 'anemia'] = 1
            break  # if a keyword is found, break out of the loop to avoid setting the value to 0 again

# Write the modified dataframe back to a new CSV file
df.to_csv('food_items.csv', index=False)
def get_healthy(x):
        print("good")
